<!DOCTYPE html>
<html lang="en">
<head>
  <title>About Us</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<ul>
  <li><a href="index.php">🏠 Home</a></li>
  <li><a href="search.php">🔍 Search</a></li>
  <li><a href="contact.php">☎ Contact</a></li>
  <li><a href="authors.php">📝 Authors</a></a></li>
  <li><a href="feedback.php">📜 Feedback</a></li>
  <li><a class="active" href="about.php">👤 About us</a></li>
</ul>
<br><br>

<div class="jumbotron text-center">
  <h1>Our Team</h1> 
</div>
  
<div class="container">
 <div class="row">
  <div class="col-md-4">
		<img src="profile2.jpg" class="img-circle" alt="Cinque Terre" width="230" height="230">
      <h3>Shubham More</h3>
	  <p><b>"</b>Started as an Hobby, doing some technical tweaks, performing some tricks; but a huge support of you people let my hobby to convert into my passion. Keeping everyone updated in terms of technology and sorting out every technical queries and issues is not just my duty but it�s my responsibility too..<b>"</b></p>
    </div>
    <div class="col-sm-4">
		<img src="profile3.jpg" class="img-circle" alt="Cinque Terre" width="230" height="230">
      <h3>Akshana Rautela</h3>
      <p><b>"</b>Having keen interest in programming and web development. I believe technology is something like breathing, and one can never compromise with it. And being a part of Fore Tech, its my responsibility to keep everyone updated about the ongoing tech stuff.<b>"</b></p>
    </div>
    <div class="col-sm-4">
		<img src="profile.jpg" class="img-circle" alt="Cinque Terre" width="230" height="230">
      <h3>PravinRaj Nadar</h3>        
      <p><b>"</b>Having interest in proggramming, always wanted to share or contribute toards something for photography, via this
		  website i am just doing my best of best to serve you better with my present and future photography skills..<b>"</b></p>
    </div>
  </div>
</div>

</body>
</html>

<!DOCTYPE html>
<html>
<head>
<style>

div.gallery {
   
  }

  div.gallery img {
      max-height: 20%;
      max-width: 100%;
      padding :  10%;
  }
  
  div.desc {
      padding: 15px;
      text-align: center;
  }
  
  * {
      box-sizing: border-box;
  }
  
  .responsive {
      padding: 0 6px;
      float: left;
      width: 24.99999%;
  }
  
  @media only screen and (max-width: 700px) {
      .responsive {
          width: 49.99999%;
          
      }
  }
  
  @media only screen and (max-width: 500px) {
      .responsive {
          width: 100%;
      }
  }
  
  .clearfix:after {
      content: "";
      display: table;
      clear: both;
  }
 
</style>
</head>
<body>
<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<ul>
  <li><a href="index.php">🏠 Home</a></li>
  <li><a href="search.php">🔍 Search</a></li>
  <li><a href="contact.php">☎ Contact</a></li>
  <li><a class="active" href="authors.php">📝 Authors</a></a></li>
  <li><a href="feedback.php">📜 Feedback</a></li>
  <li><a href="about.php">👤 About us</a></li>
</ul>
<br>
<body>
<br><br>
<h1><b><center>Hashim Badani</center></b></h1>

<h4>This photographer’s exploits usually include pictures from in and around Mumbai. He has an impeccable eye to turn these ordinary moments into extraordinary pictures. He captures well, composes well, plays beautifully with textures and the captions add a whole new dimension to his pictures. He defines himself as a ‘chronicler of mundane’ and a glimpse through his account will leave you in no doubt how extravagantly he does that. Of course it is no surprise that he is a contributing photographer to Top Gear, Lonely Planet Magazine and Rolling Stone and his pictures often get reposted by various pages.
</h4><br><br>

<div class="responsive">
  <div class="gallery">
    <a target="_blank">
      <img src="images/hb1.jpg" alt="hb1" width="500" height="300">
    </a>
    <div class="desc"></div>
  </div>
</div>

<div class="responsive">
  <div class="gallery">
    <a target="_blank">
      <img src="images/hb2.jpeg" alt="hb2" width="500" height="300">
    </a>
    <div class="desc"></div>
  </div>
</div>

<div class="responsive">
  <div class="gallery">
    <a target="_blank">
      <img src="images/hb3.jpeg" alt="hb3" width="500" height="300">
    </a>
    <div class="desc"></div>
  </div>
</div>

<div class="responsive">
  <div class="gallery">
    <a target="_blank">
      <img src="images/hb4.jpeg" alt="hb4" width="500" height="300">
    </a>
    <div class="desc"></div>
  </div>
</div>
<br><br>

<div class="responsive">
  <div class="gallery">
    <a target="_blank">
      <img src="images/hb5.jpeg" alt="hb5" width="500" height="300">
    </a>
    <div class="desc"></div>
  </div>
</div>

<div class="responsive">
  <div class="gallery">
    <a target="_blank">
      <img src="images/hb6.jpeg" alt="hb6" width="500" height="300">
    </a>
    <div class="desc"></div>
  </div>
</div>

<div class="responsive">
  <div class="gallery">
    <a target="_blank">
      <img src="images/hb7.jpeg" alt="hb7" width="500" height="300">
    </a>
    <div class="desc"></div>
  </div>
</div>

<div class="responsive">
  <div class="gallery">
    <a target="_blank">
      <img src="images/hb8.jpeg" alt="hb8" width="500" height="300">
    </a>
    <div class="desc"></div>
  </div>
</div>
<br><br>

<div class="responsive">
  <div class="gallery">
    <a target="_blank">
      <img src="images/hb9.jpg" alt="hb9" width="500" height="300">
    </a>
    <div class="desc"></div>
  </div>
</div>

<div class="responsive">
  <div class="gallery">
    <a target="_blank">
      <img src="images/hb10.jpg" alt="hb10" width="500" height="300">
    </a>
    <div class="desc"></div>
  </div>
</div>

<div class="clearfix"></div>
</body>
</html>

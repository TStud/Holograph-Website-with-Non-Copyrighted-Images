<!DOCTYPE html>
<html>
<head>
<style>

div.gallery {
   
  }
   
  div.gallery img {
      max-height: 20%;
      max-width: 100%;
      padding :  10%;
  }
  
  div.desc {
      padding: 15px;
      text-align: center;
  }
  
  * {
      box-sizing: border-box;
  }
  
  .responsive {
      padding: 0 6px;
      float: left;
      width: 24.99999%;
  }
  
  @media only screen and (max-width: 700px) {
      .responsive {
          width: 49.99999%;
          
      }
  }
  
  @media only screen and (max-width: 500px) {
      .responsive {
          width: 100%;
      }
  }
  
  .clearfix:after {
      content: "";
      display: table;
      clear: both;
  }
 
</style>
</head>
<body>
<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<ul>
  <li><a href="index.php">🏠 Home</a></li>
  <li><a href="search.php">🔍 Search</a></li>
  <li><a href="contact.php">☎ Contact</a></li>
  <li><a class="active" href="authors.php">📝 Authors</a></a></li>
  <li><a href="feedback.php">📜 Feedback</a></li>
  <li><a href="about.php">👤 About us</a></li>
</ul>
<br>
<body>
<br><br>
<h1><b><center>Nandalal Bose</center></b></h1>

<h4>
Nandalal Bose was one of the pioneers of modern Indian art and a key figure of Contextual Modernism. A pupil of Abanindranath Tagore, Bose was known for his "Indian style" of painting. He became the principal of Kala Bhavan, Santiniketan in 1922. 
Born: 3 December 1882, Munger district
Died: 16 April 1966, Kolkata
On view: National Gallery of Modern Art
Education: Government College of Art & Craft
Movement: Santiniketan: The Making of a Contextual Modernism
Parents: Kshetramonidevi, Purnachandra Bose</h4><br><br>

<div class="responsive">
  <div class="gallery">
    <a target="_blank">
      <img src="images/nb1.jpg" alt="nb1" width="500" height="300">
    </a>
    <div class="desc"></div>
  </div>
</div>

<div class="responsive">
  <div class="gallery">
    <a target="_blank">
      <img src="images/nb2.jpg" alt="nb2" width="500" height="300">
    </a>
    <div class="desc"></div>
  </div>
</div>

<div class="responsive">
  <div class="gallery">
    <a target="_blank">
      <img src="images/nb3.jpg" alt="nb3" width="500" height="300">
    </a>
    <div class="desc"></div>
  </div>
</div>

<div class="responsive">
  <div class="gallery">
    <a target="_blank">
      <img src="images/nb4.jpg" alt="nb4" width="500" height="300">
    </a>
    <div class="desc"></div>
  </div>
</div>
<br><br>

<div class="responsive">
  <div class="gallery">
    <a target="_blank">
      <img src="images/nb5.jpg" alt="nb5" width="500" height="300">
    </a>
    <div class="desc"></div>
  </div>
</div>

<div class="responsive">
  <div class="gallery">
    <a target="_blank">
      <img src="images/nb6.jpeg" alt="nb6" width="500" height="300">
    </a>
    <div class="desc"></div>
  </div>
</div>

<div class="responsive">
  <div class="gallery">
    <a target="_blank">
      <img src="images/nb7.jpeg" alt="nb7" width="500" height="300">
    </a>
    <div class="desc"></div>
  </div>
</div>

<div class="responsive">
  <div class="gallery">
    <a target="_blank">
      <img src="images/nb8.jpeg" alt="nb8" width="500" height="300">
    </a>
    <div class="desc"></div>
  </div>
</div>
<br><br>

<div class="responsive">
  <div class="gallery">
    <a target="_blank">
      <img src="images/nb9.jpeg" alt="nb9" width="500" height="300">
    </a>
    <div class="desc"></div>
  </div>
</div>

<div class="responsive">
  <div class="gallery">
    <a target="_blank">
      <img src="images/nb10.jpeg" alt="nb10" width="500" height="300">
    </a>
    <div class="desc"></div>
  </div>
</div>

<div class="clearfix"></div>
</body>
</html>

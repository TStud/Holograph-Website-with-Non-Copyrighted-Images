<?php

/* conneting to the sql database */

$servername = 'localhost';
$username = 'root';
$password = '';
$db = "foo";
$conn = new mysqli($servername, $username, $password, $db);
if ($conn->connect_error) {

	echo "error not connected";
} 
echo "connection established";

if($_SERVER["REQUEST_METHOD"]=="POST")
{
	$naam=$_POST['naam'];
	$pata=$_POST['pata'];
	$tippani=$_POST['tippani'];
	
	
	if(empty($naam))
	{
		echo "Name is empty<br>";
	}
	else if (!filter_var($pata, FILTER_VALIDATE_EMAIL)) {
	echo"Invalid email format"; 
}
else if (empty($tippani))
{
	echo"no feedback given";
	
}
	else
	{
		$st=$conn->prepare("INSERT INTO feedback VALUES (?,?,?)");
		$st->bind_param("sss",$naam,$pata,$tippani);
		$st->execute();
		$st->close();
		$conn->close();
		echo "<br>";
		echo $naam;
		echo " 's data Inserted successfully...<br>";
	}
	
}
?>
<!DOCTYPE html>
<html>
<head>
<style>

div.gallery {
   
  }

  div.gallery img {
      max-height: 20%;
      max-width: 100%;
      padding :  10%;
  }
  
  div.desc {
      padding: 15px;
      text-align: center;
  }
  
  * {
      box-sizing: border-box;
  }
  
  .responsive {
      padding: 0 6px;
      float: left;
      width: 24.99999%;
  }
  
  @media only screen and (max-width: 700px) {
      .responsive {
          width: 49.99999%;
          
      }
  }
  
  @media only screen and (max-width: 500px) {
      .responsive {
          width: 100%;
      }
  }
  
  .clearfix:after {
      content: "";
      display: table;
      clear: both;
  }
 
</style>
</head>
<body>
<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<ul>
  <li><a href="index.php">🏠 Home</a></li>
  <li><a href="search.php">🔍 Search</a></li>
  <li><a href="contact.php">☎ Contact</a></li>
  <li><a class="active" href="authors.php">📝 Authors</a></a></li>
  <li><a href="feedback.php">📜 Feedback</a></li>
  <li><a href="about.php">👤 About us</a></li>
</ul>
<br>
<body>
<br><br>
<h1><b><center>K G Subramanyam</center></b></h1>

<h4>
Kalpathi Ganpathi "K.G." Subramanyan was an Indian artist. He was awarded the Padma Vibhushan in 2012. Wikipedia
Born: 15 February 1924, Kuthuparamba
Died: 29 June 2016, Vadodara
Movement: Contextual Modernism, Baroda Group
Education: Presidency College, Chennai, Kala Bhavana
Awards: Padma Vibhushan, Padma Bhushan, Padma Shri, Kalidas Samman, Kala Ratna</h4><br><br>

<div class="responsive">
  <div class="gallery">
    <a target="_blank">
      <img src="images/kg1.jpg" alt="kg1" width="500" height="300">
    </a>
    <div class="desc"></div>
  </div>
</div>

<div class="responsive">
  <div class="gallery">
    <a target="_blank">
      <img src="images/kg2.jpeg" alt="kg2" width="500" height="300">
    </a>
    <div class="desc"></div>
  </div>
</div>

<div class="responsive">
  <div class="gallery">
    <a target="_blank">
      <img src="images/kg3.jpeg" alt="kg3" width="500" height="300">
    </a>
    <div class="desc"></div>
  </div>
</div>

<div class="responsive">
  <div class="gallery">
    <a target="_blank">
      <img src="images/kg4.jpeg" alt="kg4" width="500" height="300">
    </a>
    <div class="desc"></div>
  </div>
</div>
<br><br>

<div class="responsive">
  <div class="gallery">
    <a target="_blank">
      <img src="images/kg5.jpeg" alt="kg5" width="500" height="300">
    </a>
    <div class="desc"></div>
  </div>
</div>

<div class="responsive">
  <div class="gallery">
    <a target="_blank">
      <img src="images/kg6.jpeg" alt="kg6" width="500" height="300">
    </a>
    <div class="desc"></div>
  </div>
</div>

<div class="responsive">
  <div class="gallery">
    <a target="_blank">
      <img src="images/kg7.jpeg" alt="kg7" width="500" height="300">
    </a>
    <div class="desc"></div>
  </div>
</div>

<div class="responsive">
  <div class="gallery">
    <a target="_blank">
      <img src="images/kg8.jpeg" alt="kg8" width="500" height="300">
    </a>
    <div class="desc"></div>
  </div>
</div>
<br><br>

<div class="responsive">
  <div class="gallery">
    <a target="_blank">
      <img src="images/kg9.jpg" alt="kg9" width="500" height="300">
    </a>
    <div class="desc"></div>
  </div>
</div>

<div class="responsive">
  <div class="gallery">
    <a target="_blank">
      <img src="images/kg10.jpg" alt="kg10" width="500" height="300">
    </a>
    <div class="desc"></div>
  </div>
</div>

<div class="clearfix"></div>
</body>
</html>

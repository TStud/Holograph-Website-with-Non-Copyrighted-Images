
<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" type="text/css" href="style.css">
<script src="jquery-1.8.1.min.js" type="text/javascript"></script>
<script src="my_script.js" type="text/javascript"></script>
</head>
<body>
<ul>
  <li><a href="index.php">🏠 Home</a></li>
  <li><a href="search.php">🔍 Search</a></li>
  <li><a class="active" href="contact.php">☎ Contact</a></li>
  <li><a href="authors.php">📝 Authors</a></a></li>
  <li><a  href="feedback.php">📜 Feedback</a></li>
  <li><a href="about.php">👤 About us</a></li>
</ul>
<br>
<br>
<br>
<br>
<center>
⚫  Do you want to post your photography/art collections? Just fill the form and we may feature your work.   ⚫
<form id="myForm" action ="userInfo.php" method=post >
<br>
NAME<br>
<input type="text" name="naam"></th><br>
<br>
Email<br>
<input type="text" name="pata">
<br><br>
Feedback<br>

<textarea rows="4" cols="50" name="tippani">
</textarea>
</select>
<br><br>
<button id="sub">Save</button>

</form>
<span id="result"></span>
</center>
<script src="jquery-1.8.1.min.js" type="text/javascript"></script>
<script src="my_script.js" type="text/javascript"></script>
</body>
</html>
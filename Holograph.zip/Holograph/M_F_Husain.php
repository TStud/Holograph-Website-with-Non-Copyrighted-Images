<!DOCTYPE html>
<html>
<head>
<style>

div.gallery {
   
  }
 
  div.gallery img {
      max-height: 20%;
      max-width: 100%;
      padding :  10%;
  }
  
  div.desc {
      padding: 15px;
      text-align: center;
  }
  
  * {
      box-sizing: border-box;
  }
  
  .responsive {
      padding: 0 6px;
      float: left;
      width: 24.99999%;
  }
  
  @media only screen and (max-width: 700px) {
      .responsive {
          width: 49.99999%;
          
      }
  }
  
  @media only screen and (max-width: 500px) {
      .responsive {
          width: 100%;
      }
  }
  
  .clearfix:after {
      content: "";
      display: table;
      clear: both;
  }
 
</style>
</head>
<body>
<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<ul>
  <li><a href="index.php">🏠 Home</a></li>
  <li><a href="search.php">🔍 Search</a></li>
  <li><a href="contact.php">☎ Contact</a></li>
  <li><a class="active" href="authors.php">📝 Authors</a></a></li>
  <li><a href="feedback.php">📜 Feedback</a></li>
  <li><a href="about.php">👤 About us</a></li>
</ul>
<br>
<body>
<br><br>
<h1><b><center>M F Husain</center></b></h1>

<h4>He describes himself with these words -“Documentary & Travel Photographer. I share stories & colours of INDIA”. With no specific genre, his gallery provides a profound glimpse of India asÂ he dabbles with a wide range of subjects. While he covers plenty of portraits, the charm lies in the way he integrates the backdrop so effortlessly by adding dimensions and allowing the viewers to appreciate and take note of both the facets.
</h4><br><br>

<div class="responsive">
  <div class="gallery">
    <a target="_blank">
      <img src="images/mh1.jpeg" alt="mh1" width="500" height="300">
    </a>
    <div class="desc"></div>
  </div>
</div>

<div class="responsive">
  <div class="gallery">
    <a target="_blank">
      <img src="images/mh2.jpeg" alt="mh2" width="500" height="300">
    </a>
    <div class="desc"></div>
  </div>
</div>

<div class="responsive">
  <div class="gallery">
    <a target="_blank">
      <img src="images/mh3.jpeg" alt="mh3" width="500" height="300">
    </a>
    <div class="desc"></div>
  </div>
</div>

<div class="responsive">
  <div class="gallery">
    <a target="_blank">
      <img src="images/mh4.jpeg" alt="mh4" width="500" height="300">
    </a>
    <div class="desc"></div>
  </div>
</div>
<br><br>

<div class="responsive">
  <div class="gallery">
    <a target="_blank">
      <img src="images/mh5.jpeg" alt="mh5" width="500" height="300">
    </a>
    <div class="desc"></div>
  </div>
</div>

<div class="responsive">
  <div class="gallery">
    <a target="_blank">
      <img src="images/mh6.jpeg" alt="mh6" width="500" height="300">
    </a>
    <div class="desc"></div>
  </div>
</div>

<div class="responsive">
  <div class="gallery">
    <a target="_blank">
      <img src="images/mh7.jpeg" alt="mh7" width="500" height="300">
    </a>
    <div class="desc"></div>
  </div>
</div>

<div class="responsive">
  <div class="gallery">
    <a target="_blank">
      <img src="images/mh8.jpeg" alt="mh8" width="500" height="300">
    </a>
    <div class="desc"></div>
  </div>
</div>
<br><br>

<div class="responsive">
  <div class="gallery">
    <a target="_blank">
      <img src="images/mh9.jpeg" alt="mh9" width="500" height="300">
    </a>
    <div class="desc"></div>
  </div>
</div>

<div class="responsive">
  <div class="gallery">
    <a target="_blank">
      <img src="images/mh10.jpeg" alt="mh10" width="500" height="300">
    </a>
    <div class="desc"></div>
  </div>
</div>

<div class="clearfix"></div>
</body>
</html>

<!DOCTYPE html>
<html>
<head>
<style>

div.gallery {
   
  }
 
  div.gallery img {
      max-height: 20%;
      max-width: 100%;
      padding :  10%;
  }
  
  div.desc {
      padding: 15px;
      text-align: center;
  }
  
  * {
      box-sizing: border-box;
  }
  
  .responsive {
      padding: 0 6px;
      float: left;
      width: 24.99999%;
  }
  
  @media only screen and (max-width: 700px) {
      .responsive {
          width: 49.99999%;
          
      }
  }
  
  @media only screen and (max-width: 500px) {
      .responsive {
          width: 100%;
      }
  }
  
  .clearfix:after {
      content: "";
      display: table;
      clear: both;
  }
 
</style>
</head>
<body>
<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<ul>
  <li><a href="index.php">🏠 Home</a></li>
  <li><a href="search.php">🔍 Search</a></li>
  <li><a href="contact.php">☎ Contact</a></li>
  <li><a class="active" href="authors.php">📝 Authors</a></a></li>
  <li><a href="feedback.php">📜 Feedback</a></li>
  <li><a href="about.php">👤 About us</a></li>
</ul>
<br>
<body>
<br><br>
<h1><b><center>Raja Ravi Varma</center></b></h1>

<h4>Raja Ravi Varma was a celebrated Malayali Indian painter and artist. He is considered among the greatest painters in the history of Indian art for a number of aesthetic and broader social reasons.
Born: 29 April 1848, Kilimanoor
Died: 2 October 1906, Attingal
On view: Salar Jung Museum, National Gallery of Modern Art
Period: Academic art
Spouse: Pooruruttati Nal Bhageerathi Bayi Thampuratty (m. 1866–1906)
Education: University College Thiruvananthapuram
Children: Kerala Varma, Cheria Kochamma, Uma Amma, Mahaprabha Amma, Rama Varma
</h4><br><br>

<div class="responsive">
  <div class="gallery">
    <a target="_blank">
      <img src="images/rv1.jpg" alt="rv1" width="500" height="300">
    </a>
    <div class="desc"></div>
  </div>
</div>

<div class="responsive">
  <div class="gallery">
    <a target="_blank">
      <img src="images/rv2.jpg" alt="rv2" width="500" height="300">
    </a>
    <div class="desc"></div>
  </div>
</div>

<div class="responsive">
  <div class="gallery">
    <a target="_blank">
      <img src="images/rv3.jpg" alt="rv3" width="500" height="300">
    </a>
    <div class="desc"></div>
  </div>
</div>

<div class="responsive">
  <div class="gallery">
    <a target="_blank">
      <img src="images/rv4.jpeg" alt="rv4" width="500" height="300">
    </a>
    <div class="desc"></div>
  </div>
</div>
<br><br>

<div class="responsive">
  <div class="gallery">
    <a target="_blank">
      <img src="images/rv5.jpeg" alt="rv5" width="500" height="300">
    </a>
    <div class="desc"></div>
  </div>
</div>

<div class="responsive">
  <div class="gallery">
    <a target="_blank">
      <img src="images/rv6.jpeg" alt="rv6" width="500" height="300">
    </a>
    <div class="desc"></div>
  </div>
</div>

<div class="responsive">
  <div class="gallery">
    <a target="_blank">
      <img src="images/rv7.jpeg" alt="rv7" width="500" height="300">
    </a>
    <div class="desc"></div>
  </div>
</div>

<div class="responsive">
  <div class="gallery">
    <a target="_blank">
      <img src="images/rv8.jpeg" alt="rv8" width="500" height="300">
    </a>
    <div class="desc"></div>
  </div>
</div>
<br><br>

<div class="responsive">
  <div class="gallery">
    <a target="_blank">
      <img src="images/rv9.jpeg" alt="rv9" width="500" height="300">
    </a>
    <div class="desc"></div>
  </div>
</div>

<div class="responsive">
  <div class="gallery">
    <a target="_blank">
      <img src="images/rv10.jpeg" alt="rv10" width="500" height="300">
    </a>
    <div class="desc"></div>
  </div>
</div>

<div class="clearfix"></div>
</body>
</html>

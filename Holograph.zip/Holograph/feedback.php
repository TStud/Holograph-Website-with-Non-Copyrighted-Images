
<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<ul>
  <li><a href="index.php">🏠 Home</a></li>
  <li><a href="search.php">🔍 Search</a></li>
  <li><a href="contact.php">☎ Contact</a></li>
  <li><a href="authors.php">📝 Authors</a></a></li>
  <li><a class="active" href="feedback.php">📜 Feedback</a></li>
  <li><a href="about.php">👤 About us</a></li>
</ul>
<br>
<br>
<br>
<br>
<center>
⚫   The feedback form helps us get better. Do give us your valuable feedback   ⚫
<form name="signup" action ="connet.php" method=post >
<br>
NAME<br>
<input type="text" name="naam"></th><br>
<br>
Email<br>
<input type="text" name="pata">
<br><br>
Feedback<br>

<textarea rows="4" cols="50" name="tippani">
</textarea>
</select>
<br><br>
<input type="submit" id = "submit" value ="submit">

</form>
</center>

</body>
</html>